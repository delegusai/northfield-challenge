import {test} from 'node:test';
import assert from 'node:assert/strict';
import {findCrossings,strandY} from '../lib/braid-geometry.js';

test('crossing markers remain on both strands over sizes and a full motion cycle',()=>{
 for(const width of [320,640,1200]) for(let t=0;t<=60;t+=.137){
  const knots=findCrossings(width,t);
  assert.ok(knots.length>=5);
  for(const knot of knots){
   assert.ok(knot.x>=-30&&knot.x<=width+30);
   assert.ok(Math.abs(strandY(width,350,knot.x,knot.a,t)-strandY(width,350,knot.x,knot.b,t))<1e-8);
  }
 }
});
test('crossings move continuously between frames without two-pixel snapping',()=>{
 for(let t=0;t<20;t+=.037){
  const before=findCrossings(640,t),after=findCrossings(640,t+1/240);
  for(const knot of before){
   const next=after.find(k=>k.a===knot.a&&k.b===knot.b&&k.seed===knot.seed);
   if(next)assert.ok(Math.abs(next.x-knot.x)<.5);
  }
 }
});
test('zero-width hidden canvases have no crossing work',()=>assert.deepEqual(findCrossings(0,10),[]));
