import {test} from 'node:test';
import assert from 'node:assert/strict';
const base=process.env.TEST_URL||'http://127.0.0.1:8789';
async function api(body,cookie='',extra={}){const r=await fetch(base+'/api/challenge',{method:body?'POST':'GET',headers:{'Content-Type':'application/json','Origin':base,...(cookie?{Cookie:cookie}:{}),...extra},body:body?JSON.stringify(body):undefined});return {status:r.status,body:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0],headers:r.headers};}
const cmd=(amount,invoice,request)=>`PAY ${amount} USD TO harbor-supply FOR ${invoice} AS ${request}`;
test('real local routes isolate cookies, reject injected authority and serialize spending',async()=>{
 const initial=await api();assert.equal(initial.body.session,null);assert.equal(initial.body.ai.enabled,false);
 const created=await api({action:'start'}),cookie=created.cookie;assert.ok(cookie);assert.match(created.headers.get('set-cookie'),/HttpOnly; SameSite=Strict/);
 const missingAI=await api({action:'interpret',request:'Pay Harbor Supply $1 for inv-1.',note:''},cookie);assert.equal(missingAI.status,503);assert.equal((await api(null,cookie)).body.session.interpretations.length,0);
 const injectedAI=await api({action:'interpret',request:'Pay',note:'',OPENAI_API_KEY:'fake'},cookie);assert.equal(injectedAI.status,400);
 const injected=await api({action:'attempt',command:cmd('30000.00','over','r1'),note:'',limit:100000000},cookie);assert.equal(injected.status,400);
 const cross=await api({action:'revoke'},cookie,{Origin:'https://untrusted.invalid'});assert.equal(cross.status,403);
 const concurrent=await Promise.all([api({action:'attempt',command:cmd('15000.00','one','r1'),note:''},cookie),api({action:'attempt',command:cmd('15000.00','two','r2'),note:''},cookie)]);
 assert.deepEqual(concurrent.map(r=>r.body.decision.code).sort(),['BUDGET_EXCEEDED','RECORDED']);
 const state=await api(null,cookie);assert.equal(state.body.session.ledger.length,1);assert.equal(state.body.session.spent,1500000);
 const other=await api({action:'start'});assert.equal(other.body.session.spent,0);assert.equal((await api(null,other.cookie)).body.session.attempts.length,0);
 await api({action:'revoke'},cookie);assert.equal((await api({action:'attempt',command:cmd('1.00','new','r3'),note:''},cookie)).body.decision.code,'REVOKED');
 assert.equal((await api(null)).body.session,null);
 const bad=await api({action:'attempt',command:'x'.repeat(9000),note:''},cookie);assert.equal(bad.status,413);
 const reset=await api({action:'start'},cookie);assert.notEqual(reset.cookie,cookie);assert.equal(reset.body.session.spent,0);
});
