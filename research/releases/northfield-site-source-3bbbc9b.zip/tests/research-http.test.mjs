import {test} from 'node:test';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const base=process.env.TEST_URL||'http://127.0.0.1:8789';
if(!['localhost','127.0.0.1'].includes(new URL(base).hostname))throw new Error('HTTP tests only run on local preview.');
async function post(path,body,cookie='',origin=base){const r=await fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json',Origin:origin,Cookie:cookie},body:JSON.stringify(body)});return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};}
test('private runs, explicit owner publication, public replay evidence, immutable content and isolated ledgers',async()=>{
 const a=await post('/api/challenge',{action:'start'}),b=await post('/api/challenge',{action:'start'});
 const payload={action:'run',scenario:'overspend',source:'fixture',note:''};
 assert.equal((await post('/api/research',payload)).status,409);
 assert.equal((await post('/api/research',payload,a.cookie,'https://elsewhere.invalid')).status,403);
 assert.equal((await post('/api/research',{...payload,state:{limit:99999999}},a.cookie)).status,400);
 assert.equal((await post('/api/research',{...payload,note:'custom fixture'},a.cookie)).status,400);
 const run=await post('/api/research',payload,a.cookie);assert.equal(run.status,200);const id=run.data.id;
 assert.equal(run.data.evidence.runs[0].result.promptOnly.unauthorizedExecuted,true);assert.equal(run.data.evidence.runs[0].result.enforced.recorded,false);
 assert.equal(createHash('sha256').update(run.data.evidenceText).digest('hex'),run.data.sha256);
 assert.equal((await fetch(base+'/api/research?id='+id)).status,404);
 assert.equal((await post('/api/research',{action:'publish',id,consent:true},b.cookie)).status,404);
 assert.equal((await post('/api/research',{action:'publish',id,consent:false},a.cookie)).status,400);
 assert.equal((await post('/api/research',{action:'publish',id,consent:true},a.cookie)).status,200);
 const publicRun=await (await fetch(base+'/api/research?id='+id)).json();assert.equal(publicRun.evidenceText,run.data.evidenceText);assert.equal(publicRun.published,true);
 const snapshot=await (await fetch(base+'/api/challenge',{headers:{Cookie:a.cookie}})).json();assert.equal(snapshot.session.ledger.length,0);assert.equal(snapshot.session.interpretations.length,0);
 for(let i=1;i<20;i++)assert.equal((await post('/api/research',payload,a.cookie)).status,200);
 assert.equal((await post('/api/research',payload,a.cookie)).status,429);
});
