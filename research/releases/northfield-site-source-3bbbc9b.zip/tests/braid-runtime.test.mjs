import {test,mock} from 'node:test';
import assert from 'node:assert/strict';
import {startFabric} from '../lib/brand-braid.js';

function environment(){
 const originals=new Map(),queue=new Map(),observers={},listeners={};let now=0,id=0,text=[];
 const ctx=new Proxy({fillText:(digit,x,y)=>text.push({digit,x,y}),createLinearGradient:()=>({addColorStop(){}}),createRadialGradient:()=>({addColorStop(){}})}, {get:(obj,key)=>key in obj?obj[key]:()=>{}});
 const canvas={dataset:{ground:'#10243A'},getContext:()=>ctx,getBoundingClientRect:()=>({width:640,height:350}),classList:{add(){}},isConnected:true};
 const media={matches:false,addEventListener:(name,fn)=>listeners.media=fn,removeEventListener:()=>delete listeners.media};
 const set=(key,value)=>{originals.set(key,Object.getOwnPropertyDescriptor(globalThis,key));Object.defineProperty(globalThis,key,{value,configurable:true,writable:true});};
 set('window',{devicePixelRatio:2,matchMedia:()=>media});
 set('document',{hidden:false,createElement:()=>({getContext:()=>ctx}),addEventListener:(name,fn)=>listeners[name]=fn,removeEventListener:name=>delete listeners[name]});
 for(const name of ['IntersectionObserver','ResizeObserver','MutationObserver'])set(name,class{constructor(fn){observers[name]=fn;}observe(){}disconnect(){delete observers[name];}});
 set('requestAnimationFrame',fn=>{queue.set(++id,fn);return id;});set('cancelAnimationFrame',key=>queue.delete(key));
 const clock=mock.method(performance,'now',()=>now);
 const cleanup=startFabric(canvas);
 return {canvas,queue,media,listeners,observers,cleanup,
  visible(value){observers.IntersectionObserver([{isIntersecting:value}]);},
  advance(ms){now=ms;text=[];const calls=[...queue.values()];queue.clear();for(const call of calls)call(now);return text;},
  restore(){cleanup();clock.mock.restore();for(const [key,descriptor]of originals){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}}
 };
}

test('the actual renderer moves particles equally on 60 Hz and 120 Hz displays',()=>{
 const run=rate=>{const e=environment();try{e.visible(true);let frame;for(let i=1;i<=rate;i++)frame=e.advance(i*1000/rate);return frame;}finally{e.restore();}};
 const slow=run(60),fast=run(120);assert.equal(slow.length,fast.length);
 for(let i=0;i<slow.length;i++){assert.equal(slow[i].digit,fast[i].digit);assert.ok(Math.abs(slow[i].x-fast[i].x)<1e-8);assert.ok(Math.abs(slow[i].y-fast[i].y)<1e-8);}
});
test('pause, visibility and reduced motion stop the single frame loop, cleanup releases listeners',()=>{
 const e=environment();try{
  assert.equal(e.queue.size,0);e.visible(true);assert.equal(e.queue.size,1);e.visible(true);assert.equal(e.queue.size,1);
  e.advance(16);e.canvas.dataset.paused='true';e.observers.MutationObserver();assert.equal(e.queue.size,0);
  e.advance(10000);e.canvas.dataset.paused='false';e.observers.MutationObserver();assert.equal(e.queue.size,1);
  e.visible(false);assert.equal(e.queue.size,0);e.visible(true);assert.equal(e.queue.size,1);
  e.media.matches=true;e.listeners.media();assert.equal(e.queue.size,0);
  e.media.matches=false;e.listeners.media();assert.equal(e.queue.size,1);
  e.cleanup();assert.equal(e.queue.size,0);assert.equal(Object.keys(e.listeners).length,0);assert.equal(Object.keys(e.observers).length,0);
 }finally{e.restore();}
});
