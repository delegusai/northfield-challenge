'use client';
import {useEffect,useState} from 'react';
import ResearchShell from '../research/shell';
import Evidence,{type RunRecord} from '../research/evidence';
export default function SharedRun(){
 const [run,setRun]=useState<RunRecord|null>(null),[error,setError]=useState('');
 useEffect(()=>{const controller=new AbortController();const id=new URLSearchParams(window.location.search).get('id');if(!id){setError('No run ID was supplied.');return;}
 fetch('/api/research?id='+encodeURIComponent(id),{signal:controller.signal}).then(async r=>{const d=await r.json() as RunRecord&{error?:string};if(!r.ok)throw new Error(d.error||'Run not found.');setRun(d);}).catch(e=>{if(!controller.signal.aborted)setError(e.message);});return()=>controller.abort();},[]);
 return <ResearchShell><section className="research-intro"><p className="eyebrow">Shared test result</p><h1>See what happened. Check it yourself.</h1><p>A visitor chose to share this test. Sharing it does not mean it has been independently reviewed, endorsed, or added to the benchmark.</p><a className="text-link dark" href="/research">Run your own comparison</a></section>{error?<p role="alert" className="error">{error}</p>:run?<><Evidence run={run}/><section className="research-section"><h3>Try the replay yourself</h3><p>Download the full result and the <a href={run.evidence.kitUrl||'/research-kit.zip'}>developer kit</a>, then replay the saved proposal:</p><pre>node runner.mjs --replay northfield-{run.id}.json --out replay.json</pre><p>Replay uses the saved proposal, so it makes no AI calls. Asking the model again may give you a different answer. Check the source hashes before using a newer kit.</p></section></>:<p role="status">Loading the shared result…</p>}</ResearchShell>;
}
