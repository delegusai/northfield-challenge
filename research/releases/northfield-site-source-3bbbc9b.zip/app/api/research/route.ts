import {env} from 'cloudflare:workers';
import {RESERVE_AI_SQL,reservationArgs,MODEL} from '../../../lib/proposer';
import {VERSION,compare,POLICY} from '../../../public/research-kit/authority.mjs';
import {SCENARIOS,SUITE_VERSION} from '../../../public/research-kit/suite.mjs';
import {openAIProposal,PROMPT,modelPayload} from '../../../public/research-kit/model.mjs';
import manifest from '../../../public/research-kit/manifest.json';
export const dynamic='force-dynamic';
const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const db=()=>{if(!env.DB)throw new Error('Unavailable');return env.DB;};
async function digest(text:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),n=>n.toString(16).padStart(2,'0')).join('');}
async function owner(req:Request){const cookie=req.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('northfield_challenge='))?.slice('northfield_challenge='.length);return cookie&&/^[a-f0-9]{64}$/.test(cookie)?digest(cookie):null;}
async function readBody(req:Request){
 const reader=req.body?.getReader();if(!reader)throw new Error('Empty body');let raw='',size=0;const decoder=new TextDecoder();
 while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>8000){await reader.cancel();throw new Error('Too large');}raw+=decoder.decode(value,{stream:true});}return JSON.parse(raw+decoder.decode());
}
export async function GET(req:Request){
 try{const id=new URL(req.url).searchParams.get('id');if(!id||!/^[-a-f0-9]{36}$/.test(id))return json({error:'Run not found.'},404);
 const row=await db().prepare('SELECT evidence,digest,created FROM research_runs WHERE id=? AND published=1 AND status=\'completed\'').bind(id).first<{evidence:string;digest:string;created:number}>();
 if(!row)return json({error:'This run is not public or does not exist.'},404);
 return json({id,evidence:JSON.parse(row.evidence),evidenceText:row.evidence,sha256:row.digest,published:true});
 }catch{return json({error:'The run could not be loaded.'},503);}
}
export async function POST(req:Request){
 if(req.headers.get('Origin')!==new URL(req.url).origin)return json({error:'Use the lab page to run or publish a comparison.'},403);
 if(!req.headers.get('Content-Type')?.startsWith('application/json'))return json({error:'JSON required.'},400);
 let body;try{body=await readBody(req);}catch{return json({error:'Invalid or oversized request.'},400);}
 if(!body||typeof body!=='object'||Array.isArray(body))return json({error:'Invalid request.'},400);
 try{
 const session=await owner(req);if(!session||!await db().prepare('SELECT id FROM challenge_sessions WHERE id=?').bind(session).first())return json({error:'Start a lab session before running a comparison.'},409);
 if(body.action==='publish'){
  if(Object.keys(body).some(k=>!['action','id','consent'].includes(k))||body.consent!==true||typeof body.id!=='string')return json({error:'Review the evidence and confirm publication first.'},400);
  const row=await db().prepare("UPDATE research_runs SET published=1 WHERE id=? AND session=? AND status='completed' RETURNING id").bind(body.id,session).first();
  return row?json({id:body.id,url:'/run?id='+body.id}):json({error:'Only a completed run from your session can be published.'},404);
 }
 if(body.action!=='run'||Object.keys(body).some(k=>!['action','scenario','source','note'].includes(k))||!['fixture','model'].includes(body.source))return json({error:'Invalid comparison request.'},400);
 const selected=SCENARIOS.find(s=>s.id===body.scenario);if(!selected||typeof body.note!=='string'||body.note.length>4096)return json({error:'Select a scenario and use up to 4,096 characters of supporting text.'},400);
 if(body.source==='fixture'&&body.note!==selected.note)return json({error:'Scripted examples use their original supporting text. Choose a live model to test edits.'},400);
 if(body.source==='model'&&!env.OPENAI_API_KEY)return json({error:'Live model unavailable. Scripted examples remain available.'},503);
 const {fixture,...scenario}=selected;scenario.note=body.note;
 const id=crypto.randomUUID(),now=Date.now(),day=new Date(now).toISOString().slice(0,10);
 const admitted=await db().prepare("INSERT INTO research_runs(id,session,created,day,status) SELECT ?,id,?,?,'pending' FROM challenge_sessions WHERE id=? AND (SELECT COUNT(*) FROM research_runs WHERE session=?)<20 AND (SELECT COUNT(*) FROM research_runs WHERE day=?)<1000 RETURNING id").bind(id,now,day,session,session,day).first();
 if(!admitted)return json({error:'Comparison limit reached (20 per session, 1,000 shared per day).'},429);
 let callId:string|null=null;
 try{
  if(body.source==='model'){
   callId=crypto.randomUUID();
   const reserved=await db().prepare(RESERVE_AI_SQL).bind(...reservationArgs(callId,session,day,now,'Research comparison: '+scenario.request,scenario.note)).first();
   if(!reserved){await db().prepare("UPDATE research_runs SET status='failed' WHERE id=?").bind(id).run();return json({error:'Live runs share the lab’s limits: five per session, 100 per day, ten seconds between calls. Start a fresh session if its 15-minute authority window expired.'},429);}
  }
  const answer=body.source==='model'?await openAIProposal(scenario,{key:env.OPENAI_API_KEY,model:MODEL}):{proposal:fixture,model:null,latencyMs:null,usage:null};
  const evidence={kitUrl:'/releases/northfield-research-1.0.1.zip',protocol:VERSION,suite:SUITE_VERSION,at:new Date(now).toISOString(),mode:body.source==='model'?'agent-evaluation':'scripted-fixture',sourceHashes:manifest.files,prompt:PROMPT,modelSettings:body.source==='model'?{model:MODEL,max_output_tokens:1500,reasoning:{effort:'low'},schema:modelPayload(scenario,MODEL).text.format}:null,conditions:'Same proposal in two simulated paths. Syntax checked in both. Authority enforced only in the second. No human review, real payments, tool-use loop or concurrency test.',policy:POLICY,runs:[{scenario,trial:1,source:body.source==='model'?'live-model':'scripted-fixture',...answer,result:compare(scenario,answer.proposal)}]};
  const serialized=JSON.stringify(evidence),sha256=await digest(serialized);
  await db().prepare("UPDATE research_runs SET status='completed',evidence=?,digest=? WHERE id=?").bind(serialized,sha256,id).run();
  if(callId)await db().prepare("UPDATE challenge_ai_calls SET status='completed' WHERE id=?").bind(callId).run();
  await db().prepare('DELETE FROM research_runs WHERE published=0 AND created<?').bind(now-86400000).run();
  return json({id,evidence,evidenceText:serialized,sha256,published:false});
 }catch(error){
  console.error('Research comparison failed',{kind:error instanceof Error?error.name:'unknown',redirect:error instanceof Error&&/redirect/i.test(error.message),providerStatus:error instanceof Error?error.message.match(/HTTP ([0-9]{3})/)?.[1]:undefined});
  await db().prepare("UPDATE research_runs SET status='failed' WHERE id=?").bind(id).run();
  if(callId)await db().prepare("UPDATE challenge_ai_calls SET status='failed',error='Research comparison did not complete.' WHERE id=?").bind(callId).run();
  return json({error:'The comparison could not complete. No simulated payment was executed. Failed model calls still count toward quota.'},502);
 }
 }catch{return json({error:'Research service is temporarily unavailable.'},503);}
}
