import { env } from 'cloudflare:workers';
import { ATTEMPT_SQL,attemptArgs,LIMIT,REASONS,SUPPLIERS } from '../../../lib/rules';
import { AIError,MODEL,propose,RESERVE_AI_SQL,reservationArgs } from '../../../lib/proposer';
export const dynamic='force-dynamic';
const COOKIE='northfield_challenge';
type Attempt={id:string;created:number;command:string;note:string;amount:number;supplier:string;invoice:string;request:string;code:string};
function db(){if(!env.DB)throw new Error('Database unavailable');return env.DB;}
function json(body:unknown,status=200,cookie?:string){
 const headers=new Headers({'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
 if(cookie)headers.set('Set-Cookie',cookie);
 return new Response(JSON.stringify(body),{status,headers});
}
async function hash(token:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token))),b=>b.toString(16).padStart(2,'0')).join('');}
async function sessionId(req:Request){
 const token=req.headers.get('Cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith(COOKIE+'='))?.slice(COOKIE.length+1);
 return token&&/^[a-f0-9]{64}$/.test(token)?hash(token):null;
}
async function aiStatus(id:string|null){
 const day=new Date().toISOString().slice(0,10);
 const global=await db().prepare('SELECT COUNT(*) n FROM challenge_ai_calls WHERE day=?').bind(day).first<{n:number}>();
 const local=id?await db().prepare('SELECT COUNT(*) n FROM challenge_ai_calls WHERE session=?').bind(id).first<{n:number}>():null;
 return {enabled:!!env.OPENAI_API_KEY,model:MODEL,dailyLimit:100,dailyRemaining:Math.max(0,100-(global?.n||0)),sessionLimit:5,sessionRemaining:Math.max(0,5-(local?.n||0))};
}
async function snapshot(id:string|null){
 if(!id)return null;
 const session=await db().prepare('SELECT created,expires,revoked FROM challenge_sessions WHERE id=?').bind(id).first<{created:number;expires:number;revoked:number}>();
 if(!session)return null;
 const rows=await db().prepare('SELECT id,created,command,note,amount,supplier,invoice,request,code FROM challenge_attempts WHERE session=? ORDER BY created,rowid').bind(id).all<Attempt>();
 const interpretations=await db().prepare('SELECT id,created,request,note,status,proposal,error FROM challenge_ai_calls WHERE session=? ORDER BY created').bind(id).all<{id:string;created:number;request:string;note:string;status:string;proposal:string|null;error:string|null}>();
 const ledger=rows.results.filter(r=>r.code==='RECORDED'),spent=ledger.reduce((sum,r)=>sum+r.amount,0);
 return {reference:id.slice(0,10),created:session.created,expires:session.expires,status:session.revoked?'revoked':session.expires<=Date.now()?'expired':'active',limit:LIMIT,spent,remaining:LIMIT-spent,suppliers:SUPPLIERS,interpretations:interpretations.results.map(r=>({...r,proposal:r.proposal?JSON.parse(r.proposal):null})),attempts:rows.results.map(r=>({...r,reason:REASONS[r.code]})),ledger};
}
export async function GET(req:Request){
 try{const id=await sessionId(req);return json({session:await snapshot(id),ai:await aiStatus(id)});}
 catch{return json({error:'The challenge is temporarily unavailable. Please try again later.'},503);}
}
export async function POST(req:Request){
 if(req.headers.get('Origin')!==new URL(req.url).origin)return json({error:'Open this challenge page to submit a request.'},403);
 if(!req.headers.get('Content-Type')?.startsWith('application/json'))return json({error:'Send a JSON request.'},400);
 try{
  const reader=req.body?.getReader();if(!reader)return json({error:'Empty request.'},400);
  const chunks:Uint8Array[]=[];let size=0;
  while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>8000){await reader.cancel();return json({error:'The request is too long.'},413);}chunks.push(value);}
  const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}
  const raw=new TextDecoder().decode(bytes);
  const body=JSON.parse(raw);
  if(!body||typeof body!=='object'||Array.isArray(body))return json({error:'Invalid request.'},400);
  const expected=body.action==='attempt'?['action','command','note']:body.action==='interpret'?['action','request','note']:['action'];
  if(Object.keys(body).some(k=>!expected.includes(k)))return json({error:'Authority cannot be supplied in a payment request.'},400);
  let id=await sessionId(req);
  if(body.action==='start'){
   const now=Date.now(),day=new Date(now).toISOString().slice(0,10);
   const admitted=await db().prepare('INSERT INTO challenge_budgets(day,used) VALUES(?,1) ON CONFLICT(day) DO UPDATE SET used=used+1 WHERE used<1000 RETURNING used').bind(day).first();
   if(!admitted)return json({error:'The public challenge has reached today’s 1,000-session limit. Please return tomorrow.'},429);
   const token=Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');id=await hash(token);
   await db().batch([
    db().prepare('DELETE FROM challenge_ai_calls WHERE created<?').bind(now-86400000),
    db().prepare('DELETE FROM challenge_sessions WHERE created<?').bind(now-86400000),
    db().prepare('DELETE FROM challenge_budgets WHERE day<?').bind(new Date(now-7*86400000).toISOString().slice(0,10)),
    db().prepare('INSERT INTO challenge_sessions(id,created,expires,revoked) VALUES(?,?,?,0)').bind(id,now,now+900000),
   ]);
   const secure=new URL(req.url).protocol==='https:'?'; Secure':'';
   return json({session:await snapshot(id),ai:await aiStatus(id)},200,`${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=3600${secure}`);
  }
  if(!id||!await snapshot(id))return json({error:'Start a session before trying a payment.'},409);
  if(body.action==='revoke'){
   await db().prepare('UPDATE challenge_sessions SET revoked=1 WHERE id=?').bind(id).run();
   return json({session:await snapshot(id)});
  }
  if(body.action==='interpret'){
   if(!env.OPENAI_API_KEY)return json({error:'AI interpretation is temporarily unavailable. Command mode is still available.'},503);
   if(typeof body.request!=='string'||!body.request.trim()||body.request.length>2000||typeof body.note!=='string'||body.note.length>4096)return json({error:'Use a request of 1–2,000 characters and supporting text up to 4,096 characters.'},400);
   const callId=crypto.randomUUID(),now=Date.now(),day=new Date(now).toISOString().slice(0,10);
   const reserved=await db().prepare(RESERVE_AI_SQL).bind(...reservationArgs(callId,id,day,now,body.request,body.note)).first();
   if(!reserved){
    const ai=await aiStatus(id),state=await snapshot(id);
    const message=state?.status!=='active'?'Start a fresh active session to prepare an AI proposal.':ai.dailyRemaining===0?'Today’s shared 100-request AI limit has been reached. Command mode is still available.':ai.sessionRemaining===0?'This session has used its five AI requests. You can continue with command mode.':'Please wait at least 10 seconds between proposals. Another model request may still be running.';
    return json({error:message,ai},429);
   }
   try{
    const proposal=await propose(env.OPENAI_API_KEY,body.request,body.note,'ai-'+callId);
    await db().prepare("UPDATE challenge_ai_calls SET status='completed',proposal=? WHERE id=?").bind(JSON.stringify(proposal),callId).run();
    return json({proposal,session:await snapshot(id),ai:await aiStatus(id)});
   }catch(error){
    const message=error instanceof AIError?error.message:'The proposal could not be saved. No payment was attempted.';
    await db().prepare("UPDATE challenge_ai_calls SET status='failed',error=? WHERE id=?").bind(message,callId).run();
    return json({error:message,session:await snapshot(id),ai:await aiStatus(id)},502);
   }
  }
  if(body.action!=='attempt')return json({error:'Unknown action.'},400);
  if(typeof body.command!=='string'||body.command.length>1024||typeof body.note!=='string'||body.note.length>4096)return json({error:'Use a command up to 1,024 characters and supporting text up to 4,096 characters.'},400);
  const result=await db().prepare(ATTEMPT_SQL).bind(...attemptArgs(id,crypto.randomUUID(),Date.now(),body.command,body.note)).first<Attempt>();
  if(!result)return json({error:'This session has reached 100 attempts. Download your evidence, then start a new session.'},429);
  return json({session:await snapshot(id),decision:{...result,reason:REASONS[result.code]}});
 }catch(error){
  if(error instanceof SyntaxError)return json({error:'Invalid JSON request.'},400);
  return json({error:'The challenge could not complete this request. Refresh your session before trying again.'},503);
 }
}
