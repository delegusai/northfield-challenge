import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Northfield Challenge · Delegus',description:'Try a simulated payment, test its authority, and inspect the evidence. An independent public experiment from Delegus.',icons:{icon:'/assets/delegus-mark.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>;}
