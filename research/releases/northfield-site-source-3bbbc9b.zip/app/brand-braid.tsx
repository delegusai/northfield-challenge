
'use client';
import {useEffect,useRef,useState} from 'react';
import {Pause,Play} from 'lucide-react';
import {startFabric} from '../lib/brand-braid';
export default function BrandBraid(){
 const canvas=useRef<HTMLCanvasElement>(null);
 const [paused,setPaused]=useState(false);
 useEffect(()=>{if(canvas.current)return startFabric(canvas.current);},[]);
 return <div className="brand-braid">
  <canvas ref={canvas} className="braid-canvas" data-ground="#10243A" data-paused={paused} aria-hidden="true"/>
  <div className="braid-caption"><span><i className="strand human"/>Human intent</span><span><i className="strand agent"/>AI proposal</span><span><i className="strand check"/>Authority check</span></div>
  <button className="braid-pause" type="button" onClick={()=>setPaused(p=>!p)} aria-label={paused?'Play braid animation':'Pause braid animation'}>{paused?<Play size={12}/>:<Pause size={12}/>}<span>{paused?'Play':'Pause'} animation</span></button>
 </div>;
}
