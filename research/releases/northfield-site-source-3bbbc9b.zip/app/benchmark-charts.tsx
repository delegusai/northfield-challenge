'use client';
import {useState} from 'react';
import {ArrowUpRight,RotateCcw} from 'lucide-react';

type Trial={category:string;decision:string;passed:boolean};
type Outcome='recorded'|'blocked'|'clarify';
const palette=[
 {key:'recorded' as const,label:'Recorded',color:'#71dba5',description:'The payment passed the authority check and was added to the simulated payment record.'},
 {key:'blocked' as const,label:'Blocked',color:'#81aaff',description:'The authority check stopped the payment. Nothing was added to the payment record.'},
 {key:'clarify' as const,label:'Clarification',color:'#bca1ff',description:'The AI needed more details before it could propose a payment. Nothing was submitted.'},
];
const outcome=(decision:string):Outcome=>decision==='RECORDED'?'recorded':decision==='CLARIFICATION_REQUIRED'?'clarify':'blocked';
function count(rows:Trial[]){return rows.reduce((totals,row)=>{totals[outcome(row.decision)]++;return totals;},{recorded:0,blocked:0,clarify:0});}
export default function BenchmarkCharts({results,category,onCategory}:{results:Trial[];category:string;onCategory:(value:string)=>void}){
 const [selected,setSelected]=useState<Outcome|null>(null);
 const rows=category==='All categories'?results:results.filter(r=>r.category===category);
 const totals=count(rows),total=rows.length;
 const active=palette.find(p=>p.key===selected);
 const families=[...new Set(results.map(r=>r.category))];
 let offset=0;
 const arcs=palette.map(p=>{const share=total?totals[p.key]/total*100:0,start=offset;offset+=share;return {...p,share,start};});
 return <div className="benchmark-visuals">
  <section className="outcome-visual" aria-labelledby="outcome-chart-title">
   <div className="chart-eyebrow"><span className="chart-number">01</span> Payment outcomes</div>
   <h4 id="outcome-chart-title">What happened to the payments?</h4>
   <p className="visual-subtitle">{category==='All categories'?'All 50 scenarios · 3 trials each':category+' · '+total+' trials'}</p>
   <div className="outcome-ring" role="img" aria-label={`${total} trials: ${totals.recorded} recorded, ${totals.blocked} blocked, ${totals.clarify} clarification. ${selected?`${totals[selected]} ${selected} selected.`:''}`}>
    <svg viewBox="0 0 280 280" aria-hidden="true">
     <circle className="ring-guide" cx="140" cy="140" r="123"/>
     <circle className="ring-base" cx="140" cy="140" r="104"/>
     <g transform="rotate(-90 140 140)">{arcs.filter(p=>p.share>0).map(p=><circle key={p.key} className={`ring-segment ${selected&&selected!==p.key?'dimmed':''}`} cx="140" cy="140" r="104" pathLength="100" fill="none" stroke={p.color} strokeWidth={selected===p.key?25:20} strokeDasharray={`${p.share===100?100:Math.max(0,p.share-1.5)} 100`} strokeDashoffset={-p.start}/>)}</g>
     <circle className="ring-inner" cx="140" cy="140" r="79"/>
    </svg>
    <div className="ring-center" aria-hidden="true"><span>{active?.label||'Completed trials'}</span><strong style={active?{color:active.color}:undefined}>{selected?totals[selected]:total}</strong><small>{selected?`${total?Math.round(totals[selected]/total*100):0}% of this selection`:`${new Set(rows.map(r=>r.category)).size} test ${new Set(rows.map(r=>r.category)).size===1?'category':'categories'}`}</small></div>
   </div>
   <div className="outcome-key" aria-label="Inspect a payment outcome">{palette.map(p=><button key={p.key} className={`outcome-choice ${selected===p.key?'selected':''}`} aria-pressed={selected===p.key} onClick={()=>setSelected(s=>s===p.key?null:p.key)}><span className="outcome-dot" style={{background:p.color}}/><span>{p.label}</span><strong>{totals[p.key]}</strong><span className="outcome-percent">{total?Math.round(totals[p.key]/total*100):0}%</span></button>)}</div>
   <p className="outcome-explanation" aria-live="polite">{active?.description||'Choose an outcome to see what it means. Sometimes the right answer is to pay; sometimes it is to say no or ask for more details.'}</p>
  </section>
  <section className="category-visual" aria-labelledby="category-chart-title">
   <div className="chart-eyebrow"><span className="chart-number">02</span> Category breakdown</div>
   <h4 id="category-chart-title">How did each type of test go?</h4>
   <p className="visual-subtitle">Choose a category to see the individual tests below.</p>
   <div className="category-legend" aria-label="Chart legend">{palette.map(p=><span key={p.key}><i className={`legend-dot ${p.key}`}/>{p.label}</span>)}</div>
   <div className="category-column-labels"><span>Test category</span><span>Share of outcomes</span><span>Matched<sup>*</sup></span></div>
   <div className="category-bars">{families.map(name=>{const group=results.filter(r=>r.category===name),counts=count(group),passed=group.filter(r=>r.passed).length,isSelected=category===name;return <button type="button" key={name} className={`category-bar-row ${isSelected?'selected':''} ${category!=='All categories'&&!isSelected?'muted-row':''}`} onClick={()=>onCategory(isSelected?'All categories':name)} aria-pressed={isSelected} aria-label={`${name}: ${counts.recorded} recorded, ${counts.blocked} blocked, ${counts.clarify} clarification; ${passed} of ${group.length} matched expectations. ${isSelected?'Clear filter':'Filter category'}.`} title={`${counts.recorded} recorded · ${counts.blocked} blocked · ${counts.clarify} clarification`}>
    <span className="category-name">{name}<ArrowUpRight size={12}/></span>
    <span className="category-stack" aria-hidden="true">{palette.map(p=>counts[p.key]>0&&<span key={p.key} className={`stack-segment ${p.key}`} style={{width:`${counts[p.key]/group.length*100}%`}}>{counts[p.key]>=3?counts[p.key]:''}</span>)}</span>
    <span className={`category-matched ${passed===group.length?'all-matched':''}`}>{passed}<span>/{group.length}</span></span>
   </button>;})}</div>
   <div className="category-axis" aria-hidden="true"><span/><div><span>0%</span><span>50%</span><span>100%</span></div><span/></div>
   <div className="category-note"><p><sup>*</sup> Both the AI’s reading of the request and the final decision were as expected. Numbers inside the bars show how many trials had each outcome.</p>{category!=='All categories'&&<button onClick={()=>onCategory('All categories')}><RotateCcw size={12}/> Reset filter</button>}</div>
  </section>
 </div>;
}
