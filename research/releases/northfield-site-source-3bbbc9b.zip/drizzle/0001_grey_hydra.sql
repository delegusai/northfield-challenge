CREATE TABLE `challenge_ai_calls` (
	`id` text PRIMARY KEY NOT NULL,
	`session` text,
	`day` text NOT NULL,
	`created` integer NOT NULL,
	`request` text NOT NULL,
	`note` text NOT NULL,
	`status` text NOT NULL,
	`proposal` text,
	`error` text,
	FOREIGN KEY (`session`) REFERENCES `challenge_sessions`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `ai_day` ON `challenge_ai_calls` (`day`);--> statement-breakpoint
CREATE INDEX `ai_session` ON `challenge_ai_calls` (`session`);--> statement-breakpoint
CREATE INDEX `ai_status_created` ON `challenge_ai_calls` (`status`,`created`);