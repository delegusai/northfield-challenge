CREATE TABLE `research_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`session` text,
	`created` integer NOT NULL,
	`day` text NOT NULL,
	`status` text NOT NULL,
	`published` integer DEFAULT 0 NOT NULL,
	`evidence` text,
	`digest` text,
	FOREIGN KEY (`session`) REFERENCES `challenge_sessions`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `research_session` ON `research_runs` (`session`);--> statement-breakpoint
CREATE INDEX `research_day` ON `research_runs` (`day`);