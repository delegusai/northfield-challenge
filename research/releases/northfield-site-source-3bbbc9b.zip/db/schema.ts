import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const sessions=sqliteTable('challenge_sessions',{
 id:text('id').primaryKey(),created:integer('created').notNull(),expires:integer('expires').notNull(),revoked:integer('revoked').notNull().default(0),
},t=>[index('session_created').on(t.created)]);
export const attempts=sqliteTable('challenge_attempts',{
 id:text('id').primaryKey(),session:text('session').notNull().references(()=>sessions.id,{onDelete:'cascade'}),
 created:integer('created').notNull(),command:text('command').notNull(),note:text('note').notNull(),
 amount:integer('amount').notNull(),supplier:text('supplier').notNull(),invoice:text('invoice').notNull(),request:text('request').notNull(),code:text('code').notNull(),
},t=>[index('attempt_session').on(t.session)]);
export const budgets=sqliteTable('challenge_budgets',{day:text('day').primaryKey(),used:integer('used').notNull()});
export const aiCalls=sqliteTable('challenge_ai_calls',{
 id:text('id').primaryKey(),session:text('session').references(()=>sessions.id,{onDelete:'set null'}),
 day:text('day').notNull(),created:integer('created').notNull(),request:text('request').notNull(),note:text('note').notNull(),
 status:text('status').notNull(),proposal:text('proposal'),error:text('error'),
},t=>[index('ai_day').on(t.day),index('ai_session').on(t.session),index('ai_status_created').on(t.status,t.created)]);

// Only explicitly published research runs survive ordinary private-session cleanup.
export const researchRuns=sqliteTable('research_runs',{
 id:text('id').primaryKey(),session:text('session').references(()=>sessions.id,{onDelete:'set null'}),
 created:integer('created').notNull(),day:text('day').notNull(),status:text('status').notNull(),
 published:integer('published').notNull().default(0),evidence:text('evidence'),digest:text('digest'),
},t=>[index('research_session').on(t.session),index('research_day').on(t.day)]);
