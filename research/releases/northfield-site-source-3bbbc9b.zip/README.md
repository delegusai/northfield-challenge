# Northfield public challenge

A separate, public AI-and-command simulation with a branded guide, interactive test bench, per-session evidence, and charts sourced from the original 150-trial AI benchmark.

## Research workbench

The new [research workbench](https://lab.delegus.ai/research) adds paired execution comparisons, explicitly published run pages, and a standalone Node.js developer kit. See RESEARCH.md and public/research-kit/README.md for the protocol, reproduction instructions, privacy and limits. The source download and developer kit contain the exact comparison implementation. Research runs remain separate from the older benchmark.

## Current status

Natural-language requests use `gpt-5.4-mini` to prepare a structured proposal or ask for clarification. Visitors review the exact command before separately submitting it to the server-side D1 authority check. The model has no tools and cannot execute payments or change authority. Command mode remains available independently.

The owner authorized reusing the local experiment key as a private Sites runtime secret. It is not stored in this checkout, source history, browser code, or the deployment archive. The only credential-bearing destination is the fixed OpenAI Responses endpoint, with redirects refused. Fictional requests and supporting text are sent with `store:false`, a 1,500 output-token cap and 25-second fetch timeout. These controls are request/token caps, not a dollar budget or proof of provider deletion. No automatic retries occur.

## Isolation and limits

Each visitor receives a random 256-bit HTTP-only SameSite cookie (Secure on HTTPS). Only its SHA-256 hash is stored as the session identifier. No cookie or session bearer value is exported. The session starts with $25,000 and two approved suppliers; the payment window lasts 15 minutes. Each session allows 100 attempts. New sessions share a global 1,000-per-UTC-day limit. AI requests share a hard global cap of 100 per UTC day, with five per session, ten seconds between requests, one pending call per session, and at most three recent pending calls globally. A single serialized D1 insertion reserves quota before calling OpenAI; failures consume quota. Creating sessions or deleting an old session does not restore the global quota. Pending calls age out of the concurrency guard after 60 seconds, but remain counted toward daily/session limits.

All visitor data is separate from the benchmark, which is an immutable synthetic snapshot.

A single SQL insertion computes the payment decision against current state and records it atomically. Accepted attempts are the ledger. The server checks aggregate spending, approved suppliers, duplicate successful requests, duplicate supplier/invoice pairs, revocation, and expiry. The request cannot provide authority. All SQL values are bound parameters. Request bodies are bounded while streaming, and cross-origin writes are refused.

AI requests, model proposals, and payment records become eligible for deletion after 24 hours; starting another session runs cleanup, so inactive deployments may retain records longer. No public visitor leaderboard, personal-data collection, real payment system, or live Delegus integration is included. Research runs can be explicitly published separately; published evidence persists beyond session cleanup. Downloads are unsigned prototype evidence.

## Verification

- `node --test tests/rules.test.mjs`: 11 parser/database tests.
- `node --test tests/proposer.test.mjs`: 10 validation, transport, and quota tests; no live API calls.
- With the built preview running: `node --test tests/http.test.mjs`: cookie isolation, injected authority rejection, cross-origin rejection, concurrent spending, revocation, body limits and reset.
- `npx tsc --noEmit`: type check.
- Build and local migrations follow the Sites workflow. Tests use local D1 only.

The actual browser flow was checked on desktop and at 390 pixels, with no horizontal mobile overflow or browser errors. A valid $1,250 payment recorded once; a $30,000 payment with a misleading note was blocked, and authority withdrawal blocked a later request. Downloaded evidence contained three attempts and one ledger entry. The category filter changed charts from 150 trials to 15 authority-change trials, all blocked as expected. A fresh mobile session recorded a valid payment.

The benchmark is 50 fixed scenarios × three repeats, not visitor totals or a security guarantee. Public assets and font notices originate from the authorized public Delegus branding.
