# Research release 1.0

Entry point: https://lab.delegus.ai/research

The public research kit is versioned independently as northfield-authority/1.0.0 and northfield-starter/1.0.0. Browser/API comparisons import the same public kit modules used by the downloadable local runner. A separate differential test checks that the in-memory authority evaluator matches the hosted payment SQL for the starter scenarios. This is not a proof of equivalence for all states or a concurrency benchmark.

Research API:
- POST /api/research action run with scenario ID, source fixture/model, note. Requires the existing lab session cookie and same-origin JSON request. Initial state is always selected server-side. Custom client policy/state/proposals are rejected.
- POST action publish with run ID and consent true. Only the owning session can publish its completed run. Evidence is immutable after creation. No arbitrary reports can be uploaded through this API.
- GET /api/research?id=UUID returns explicitly published evidence only, plus the exact serialized JSON and its SHA-256 digest. This is not a cryptographic attestation by an independent party.

Research writes are capped at 20 per session and 1,000 globally per UTC day. Live calls reuse the existing atomic five/session, 100/day reservation, cooldown and concurrency control. Fixture runs never call a model. Failed calls consume the model quota. Published evidence survives session cleanup through a nullable session reference; private evidence is eligible for deletion after 24 hours when another research run completes. Published runs are available while the lab operates; this prototype does not promise permanent archival hosting. No public run directory or leaderboard is generated.

The public UI requires a separate explicit publication checkbox and button after displaying all evidence. Published data includes user-supplied notes and model output. React renders this as text; there is no HTML execution, external URL fetching or arbitrary agent execution on the server. Local custom adapters are developer-controlled code.

## Build and check

npm run install:ci
node --test tests/rules.test.mjs tests/proposer.test.mjs tests/research.test.mjs
node scripts/package-research.mjs
npx tsc --noEmit
npm run build

For independent hosting, configure a fresh D1 binding named DB and apply the ordered drizzle migrations. The Sites hosting manifest/project identity, provider keys, original benchmark dataset, branding assets, fonts, and local runtime data are excluded from the source download. Supply your own assets or remove their references. This source download documents the application and experiment; the standalone developer kit is the immediately runnable artifact.

Browser checks include both comparison sources, independent ledgers, explicit publish and cross-session public retrieval, checksum verification, offline replay, private-read rejection, same-origin/body/owner validation and responsive phone layout. Tests must run before claiming these checks passed.

Research kit code/scenarios are MIT; the source archive does not grant rights to Delegus branding or unrelated third-party code. See public/research-kit/LICENSE.
