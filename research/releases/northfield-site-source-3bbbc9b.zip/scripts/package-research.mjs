import {readFile,writeFile,copyFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
await copyFile('lib/rules.ts','public/research-kit/server-rules.ts');
const files={};for(const name of ['authority.mjs','suite.mjs','model.mjs','runner.mjs','server-rules.ts'])files[name]=createHash('sha256').update(await readFile('public/research-kit/'+name)).digest('hex');
await writeFile('public/research-kit/manifest.json',JSON.stringify({protocol:'northfield-authority/1.0.0',suite:'northfield-starter/1.0.0',files},null,2)+'\n');
// Explicit source allowlist: never sweep credentials, runtime data, dependencies or brand assets.
execFileSync('python3',['-c',`
import pathlib,zipfile
root=pathlib.Path('.')
kit=pathlib.Path('public/research-kit')
with zipfile.ZipFile('public/research-kit.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(kit.iterdir()):
  if p.is_file(): z.write(p,p.name)
with zipfile.ZipFile('public/research-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for base in ['app','lib','db','drizzle','tests','scripts','worker','public/research-kit']:
  for p in sorted((root/base).rglob('*')):
   if p.is_file() and p.suffix in ['.ts','.tsx','.js','.mjs','.mts','.json','.sql','.css','.md','.sh']: z.write(p,str(p))
 for name in ['package.json','package-lock.json','tsconfig.json','vite.config.ts','next.config.ts','cloudflare-env.d.ts','README.md','RESEARCH.md']:
  z.write(name,name)
 # Hosting identity is intentionally omitted; a new host must create separate resources.
`]);
await mkdir('public/releases',{recursive:true});
await copyFile('public/research-kit.zip','public/releases/northfield-research-1.0.1.zip');
console.log('Research kit, source archive and source checksums prepared.');
